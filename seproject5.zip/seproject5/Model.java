package seproject5;

public class Model {

	public Model() {
		// TODO Auto-generated constructor stub
	}

}
