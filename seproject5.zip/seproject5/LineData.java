package seproject5;

public class LineData {

	public LineData() {
		// TODO Auto-generated constructor stub
	}

}
