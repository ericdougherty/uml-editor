package seproject5;

public class RectangleData {

	public RectangleData() {
		// TODO Auto-generated constructor stub
	}

}
